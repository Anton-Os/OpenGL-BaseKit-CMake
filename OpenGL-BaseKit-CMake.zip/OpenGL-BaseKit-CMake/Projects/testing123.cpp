#include <iostream>
using namespace std;

/* #define FREEGLUT_STATIC */

/* ALWAYS include glew.h before freeglut.h dont fuck it up */
#include <GL/glew.h>
#include <GL/freeglut.h>

int testGLEW() {
    GLenum err = glewInit();
    if (GLEW_OK == err) {
        cout << "Fix your GLEW you f***" << endl;
        return 0;
    }

    cout << "GLEW has been built successfully!!!" << endl;
    return 0;
}

int main(int argc, char ** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_RGBA);
    testGLEW();

    return 0;
}